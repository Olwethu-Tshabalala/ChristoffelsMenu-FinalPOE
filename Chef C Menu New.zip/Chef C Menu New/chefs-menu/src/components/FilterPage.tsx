import React, { useState, useMemo } from "react";
import { MenuItem } from "./CategoryPage";

interface FilterPageProps {
  items: MenuItem[];
  onBack: () => void;
}

const FilterPage: React.FC<FilterPageProps> = ({ items, onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("name");

  const categories = ["All", "Starters", "Mains", "Desserts"];

  const filteredItems = useMemo(() => {
    let filtered = items.filter(item => {
      const categoryMatch = selectedCategory === "All" || item.category === selectedCategory;
      const priceMatch = item.price >= priceRange[0] && item.price <= priceRange[1];
      const searchMatch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      return categoryMatch && priceMatch && searchMatch;
    });

    // Sort items
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "price":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "category":
          return a.category.localeCompare(b.category);
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return filtered;
  }, [items, selectedCategory, priceRange, searchTerm, sortBy]);

  const totalValue = filteredItems.reduce((sum, item) => sum + item.price, 0);
  const averagePrice = filteredItems.length > 0 ? totalValue / filteredItems.length : 0;

  const clearFilters = () => {
    setSelectedCategory("All");
    setPriceRange([0, 1000]);
    setSearchTerm("");
    setSortBy("name");
  };

  const activeFilters = [
    selectedCategory !== "All",
    priceRange[0] > 0 || priceRange[1] < 1000,
    searchTerm.trim() !== ""
  ].filter(Boolean).length;

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <button onClick={onBack} style={styles.backBtn}>
          ← Back to Menu
        </button>
        
        <div style={styles.titleSection}>
          <h1 style={styles.title}>🔍 Dish Explorer</h1>
          <p style={styles.subtitle}>Discover and filter through your culinary creations</p>
        </div>

        <div style={styles.headerStats}>
          <div style={styles.statBadge}>
            <span style={styles.statNumber}>{items.length}</span>
            <span style={styles.statLabel}>Total Dishes</span>
          </div>
        </div>
      </div>

      <div style={styles.content}>
        {/* Filters Sidebar */}
        <div style={styles.sidebar}>
          <div style={styles.filterCard}>
            <div style={styles.filterHeader}>
              <h3 style={styles.filterTitle}>
                ⚙️ Filters
                {activeFilters > 0 && (
                  <span style={styles.activeFiltersBadge}>{activeFilters}</span>
                )}
              </h3>
              {activeFilters > 0 && (
                <button onClick={clearFilters} style={styles.clearButton}>
                  Clear All
                </button>
              )}
            </div>

            {/* Search Filter */}
            <div style={styles.filterGroup}>
              <label style={styles.label}>🔍 Search Dishes</label>
              <div style={styles.searchContainer}>
                <input
                  type="text"
                  placeholder="Search by name or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={styles.searchInput}
                />
              </div>
            </div>

            {/* Category Filter */}
            <div style={styles.filterGroup}>
              <label style={styles.label}>📁 Category</label>
              <div style={styles.categoryButtons}>
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    style={{
                      ...styles.categoryBtn,
                      ...(selectedCategory === cat ? styles.categoryBtnActive : {})
                    }}
                  >
                    {cat}
                    {cat !== "All" && (
                      <span style={styles.categoryEmoji}>
                        {cat === "Starters" ? "🥗" : cat === "Mains" ? "🍖" : "🍰"}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div style={styles.filterGroup}>
              <label style={styles.label}>💰 Price Range: R{priceRange[0]} - R{priceRange[1]}</label>
              <div style={styles.rangeContainer}>
                <input
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                  style={styles.range}
                />
                <input
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  style={styles.range}
                />
              </div>
              <div style={styles.rangeLabels}>
                <span>R0</span>
                <span>R1000</span>
              </div>
            </div>

            {/* Sort Filter */}
            <div style={styles.filterGroup}>
              <label style={styles.label}>📊 Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={styles.select}
              >
                <option value="name">Name (A-Z)</option>
                <option value="price">Price (Low to High)</option>
                <option value="price-desc">Price (High to Low)</option>
                <option value="category">Category</option>
              </select>
            </div>
          </div>

          {/* Statistics Card */}
          <div style={styles.statsCard}>
            <h4 style={styles.statsTitle}>Menu Insights</h4>
            <div style={styles.statItem}>
              <span style={styles.statItemLabel}>Total Dishes</span>
              <span style={styles.statItemValue}>{items.length}</span>
            </div>
            <div style={styles.statItem}>
              <span style={styles.statItemLabel}>Showing</span>
              <span style={styles.statItemValue}>{filteredItems.length}</span>
            </div>
            <div style={styles.statItem}>
              <span style={styles.statItemLabel}>Average Price</span>
              <span style={styles.statItemValue}>R{averagePrice.toFixed(2)}</span>
            </div>
            <div style={styles.statItem}>
              <span style={styles.statItemLabel}>Total Value</span>
              <span style={styles.statItemValue}>R{totalValue.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div style={styles.results}>
          <div style={styles.resultsHeader}>
            <div>
              <h2 style={styles.resultsTitle}>
                {selectedCategory === "All" ? "📊" : 
                 selectedCategory === "Starters" ? "🥗" :
                 selectedCategory === "Mains" ? "🍖" : "🍰"} 
                {selectedCategory} Dishes ({filteredItems.length})
              </h2>
              <p style={styles.resultsSubtitle}>
                {filteredItems.length === items.length 
                  ? "Showing all dishes" 
                  : `Filtered from ${items.length} total dishes`
                }
              </p>
            </div>
            
            <div style={styles.resultsStats}>
              <div style={styles.resultStat}>
                <span style={styles.resultStatValue}>R{totalValue.toFixed(2)}</span>
                <span style={styles.resultStatLabel}>Total Value</span>
              </div>
            </div>
          </div>

          {filteredItems.length === 0 ? (
            <div style={styles.noResults}>
              <div style={styles.noResultsContent}>
                <div style={styles.noResultsEmoji}>🔍</div>
                <h3 style={styles.noResultsTitle}>No dishes found</h3>
                <p style={styles.noResultsText}>
                  {items.length === 0 
                    ? "You haven't added any dishes yet. Start by creating some delicious dishes!"
                    : "Try adjusting your filters or search terms to see more results."
                  }
                </p>
                {items.length === 0 && (
                  <button onClick={onBack} style={styles.noResultsAction}>
                    Start Creating Dishes
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div style={styles.dishesGrid}>
              {filteredItems.map((item, index) => (
                <div key={index} style={styles.dishCard}>
                  <div style={styles.dishHeader}>
                    <h3 style={styles.dishName}>{item.name}</h3>
                    <div style={{
                      ...styles.priceTag,
                      background: item.category === "Starters" 
                        ? "linear-gradient(135deg, #4CAF50, #45a049)"
                        : item.category === "Mains"
                        ? "linear-gradient(135deg, #FF9800, #f57c00)"
                        : "linear-gradient(135deg, #E91E63, #c2185b)"
                    }}>
                      R{item.price.toFixed(2)}
                    </div>
                  </div>
                  
                  <div style={styles.dishCategoryTag}>
                    <span style={styles.categoryEmojiSmall}>
                      {item.category === "Starters" ? "🥗" : 
                       item.category === "Mains" ? "🍖" : "🍰"}
                    </span>
                    {item.category}
                  </div>
                  
                  <p style={styles.dishDescription}>{item.description}</p>
                  
                  <div style={styles.dishFooter}>
                    <button style={styles.viewButton}>
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)",
    fontFamily: "'Poppins', sans-serif, Arial, sans-serif"
  },
  header: {
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    padding: "2rem",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)"
  },
  backBtn: {
    background: "#f44336",
    border: "none",
    color: "white",
    padding: "0.75rem 1.5rem",
    borderRadius: "25px",
    cursor: "pointer",
    fontWeight: "600",
    boxShadow: "0 4px 15px rgba(244, 67, 54, 0.3)"
  },
  titleSection: {
    textAlign: "center",
    flex: 1
  },
  title: {
    fontSize: "2.5rem",
    fontWeight: "bold",
    margin: "0 0 0.5rem 0",
    textShadow: "2px 2px 4px rgba(0,0,0,0.3)"
  },
  subtitle: {
    fontSize: "1.1rem",
    opacity: 0.9,
    margin: 0,
    fontWeight: "300"
  },
  headerStats: {
    display: "flex",
    gap: "1rem"
  },
  statBadge: {
    background: "rgba(255,255,255,0.2)",
    padding: "0.75rem 1rem",
    borderRadius: "15px",
    textAlign: "center"
  },
  statNumber: {
    fontSize: "1.3rem",
    fontWeight: "bold",
    display: "block"
  },
  statLabel: {
    fontSize: "0.8rem",
    opacity: 0.9
  },
  content: {
    display: "flex",
    gap: "2rem",
    padding: "2rem",
    maxWidth: "1400px",
    margin: "0 auto"
  },
  sidebar: {
    width: "300px",
    display: "flex",
    flexDirection: "column",
    gap: "1.5rem"
  },
  filterCard: {
    background: "white",
    borderRadius: "20px",
    padding: "1.5rem",
    boxShadow: "0 8px 32px rgba(0,0,0,0.1)"
  },
  filterHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "1.5rem",
    paddingBottom: "1rem",
    borderBottom: "2px solid #f0f0f0"
  },
  filterTitle: {
    margin: 0,
    color: "#333",
    fontSize: "1.3rem",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem"
  },
  activeFiltersBadge: {
    background: "#ff4757",
    color: "white",
    borderRadius: "10px",
    padding: "0.2rem 0.6rem",
    fontSize: "0.7rem",
    fontWeight: "bold"
  },
  clearButton: {
    background: "none",
    border: "1px solid #ddd",
    color: "#666",
    padding: "0.4rem 0.8rem",
    borderRadius: "15px",
    cursor: "pointer",
    fontSize: "0.8rem"
  },
  filterGroup: {
    marginBottom: "1.5rem"
  },
  label: {
    display: "block",
    marginBottom: "0.75rem",
    fontWeight: "600",
    color: "#333",
    fontSize: "0.9rem"
  },
  searchContainer: {
    position: "relative",
    display: "flex",
    alignItems: "center"
  },
  searchInput: {
    width: "100%",
    padding: "0.75rem 1rem",
    border: "2px solid #e0e0e0",
    borderRadius: "10px",
    fontSize: "0.9rem",
    outline: "none",
    fontFamily: "inherit"
  },
  categoryButtons: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem"
  },
  categoryBtn: {
    background: "none",
    border: "2px solid #e0e0e0",
    padding: "0.75rem 1rem",
    borderRadius: "10px",
    cursor: "pointer",
    fontSize: "0.9rem",
    fontWeight: "500",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  categoryBtnActive: {
    background: "linear-gradient(135deg, #667eea, #764ba2)",
    color: "white",
    borderColor: "transparent"
  },
  categoryEmoji: {
    fontSize: "1rem"
  },
  rangeContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem"
  },
  range: {
    width: "100%",
    height: "6px",
    borderRadius: "3px",
    background: "#ddd",
    outline: "none"
  },
  rangeLabels: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "0.8rem",
    color: "#666",
    fontWeight: "500"
  },
  select: {
    width: "100%",
    padding: "0.75rem 1rem",
    border: "2px solid #e0e0e0",
    borderRadius: "10px",
    fontSize: "0.9rem",
    background: "white",
    cursor: "pointer",
    outline: "none",
    fontFamily: "inherit"
  },
  statsCard: {
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    borderRadius: "20px",
    padding: "1.5rem",
    boxShadow: "0 8px 32px rgba(0,0,0,0.1)"
  },
  statsTitle: {
    margin: "0 0 1rem 0",
    fontSize: "1.1rem",
    textAlign: "center"
  },
  statItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0.5rem 0",
    borderBottom: "1px solid rgba(255,255,255,0.1)"
  },
  statItemLabel: {
    fontSize: "0.8rem",
    opacity: 0.9
  },
  statItemValue: {
    fontSize: "0.9rem",
    fontWeight: "600"
  },
  results: {
    flex: 1,
    display: "flex",
    flexDirection: "column"
  },
  resultsHeader: {
    background: "white",
    borderRadius: "20px",
    padding: "1.5rem 2rem",
    marginBottom: "1.5rem",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  resultsTitle: {
    margin: "0 0 0.5rem 0",
    color: "#333",
    fontSize: "1.5rem"
  },
  resultsSubtitle: {
    margin: 0,
    color: "#666",
    fontSize: "0.9rem"
  },
  resultsStats: {
    display: "flex",
    gap: "1rem"
  },
  resultStat: {
    textAlign: "center"
  },
  resultStatValue: {
    display: "block",
    fontSize: "1.3rem",
    fontWeight: "bold",
    color: "#4CAF50"
  },
  resultStatLabel: {
    fontSize: "0.8rem",
    color: "#666"
  },
  noResults: {
    background: "white",
    borderRadius: "20px",
    padding: "3rem 2rem",
    textAlign: "center",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  noResultsContent: {
    maxWidth: "400px"
  },
  noResultsEmoji: {
    fontSize: "4rem",
    marginBottom: "1rem",
    opacity: 0.7
  },
  noResultsTitle: {
    fontSize: "1.5rem",
    margin: "0 0 1rem 0",
    color: "#333"
  },
  noResultsText: {
    fontSize: "1rem",
    margin: "0 0 2rem 0",
    color: "#666",
    lineHeight: "1.6"
  },
  noResultsAction: {
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    border: "none",
    padding: "1rem 2rem",
    borderRadius: "25px",
    fontSize: "1rem",
    fontWeight: "600",
    cursor: "pointer"
  },
  dishesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
    gap: "1.5rem"
  },
  dishCard: {
    background: "white",
    borderRadius: "15px",
    padding: "1.5rem",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    border: "1px solid rgba(255,255,255,0.2)"
  },
  dishHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "1rem"
  },
  dishName: {
    margin: "0",
    color: "#333",
    fontSize: "1.2rem",
    fontWeight: "600",
    flex: 1,
    marginRight: "1rem"
  },
  priceTag: {
    color: "white",
    padding: "0.4rem 0.8rem",
    borderRadius: "15px",
    fontSize: "0.9rem",
    fontWeight: "bold"
  },
  dishCategoryTag: {
    background: "rgba(116, 185, 255, 0.1)",
    color: "#74b9ff",
    padding: "0.4rem 0.8rem",
    borderRadius: "12px",
    fontSize: "0.8rem",
    fontWeight: "600",
    display: "inline-flex",
    alignItems: "center",
    gap: "0.4rem",
    marginBottom: "1rem"
  },
  categoryEmojiSmall: {
    fontSize: "0.8rem"
  },
  dishDescription: {
    margin: "0 0 1.5rem 0",
    color: "#666",
    lineHeight: "1.5",
    fontStyle: "italic",
    fontSize: "0.9rem"
  },
  dishFooter: {
    display: "flex",
    justifyContent: "flex-end"
  },
  viewButton: {
    background: "linear-gradient(135deg, #74b9ff, #0984e3)",
    color: "white",
    border: "none",
    padding: "0.5rem 1rem",
    borderRadius: "10px",
    fontSize: "0.8rem",
    fontWeight: "600",
    cursor: "pointer"
  }
};

export default FilterPage;