import React, { useEffect, useState } from "react";

interface SplashProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashProps> = ({ onFinish }) => {
  const [fadeOut, setFadeOut] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 40);

    const timer = setTimeout(() => {
      setFadeOut(true);
      setTimeout(onFinish, 600);
    }, 2000);

    return () => {
      clearInterval(progressInterval);
      clearTimeout(timer);
    };
  }, [onFinish]);

  return (
    <div style={{
      ...styles.container,
      opacity: fadeOut ? 0 : 1,
      transition: 'all 0.6s ease-in-out'
    }}>
      {/* Background Image with Overlay */}
      <div style={styles.backgroundImage}></div>
      
      {/* Main Content */}
      <div style={styles.content}>
        <div style={styles.chefContainer}>
          <div style={styles.chefImage}></div>
          <div style={styles.cookingBubbles}>
            <div style={styles.bubble}></div>
            <div style={styles.bubble}></div>
            <div style={styles.bubble}></div>
          </div>
        </div>
        
        <h1 style={styles.title}>
          Chef's
          <span style={styles.titleAccent}> Menu</span>
        </h1>
        
        <p style={styles.subtitle}>Crafting Culinary Excellence</p>
        
        {/* Animated Progress Bar */}
        <div style={styles.progressContainer}>
          <div 
            style={{
              ...styles.progressBar,
              width: `${progress}%`
            }}
          ></div>
          <div style={styles.progressText}>
            {progress}%
          </div>
        </div>

        {/* Loading Dots */}
        <div style={styles.loadingDots}>
          <div style={styles.dot}></div>
          <div style={styles.dot}></div>
          <div style={styles.dot}></div>
        </div>
      </div>

      {/* Footer */}
      <div style={styles.footer}>
        <p style={styles.footerText}>Preparing your kitchen experience...</p>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    color: "white",
    fontFamily: "'Poppins', sans-serif",
    position: "relative",
    overflow: "hidden"
  },
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundImage: "url('https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    filter: "brightness(0.4)",
    zIndex: -2
  },
  content: {
    textAlign: "center",
    zIndex: 2,
    position: "relative"
  },
  chefContainer: {
    position: "relative",
    marginBottom: "2rem"
  },
  chefImage: {
    width: "120px",
    height: "120px",
    backgroundImage: "url('https://images.unsplash.com/photo-1583394293214-28ded15ee548?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    borderRadius: "50%",
    margin: "0 auto",
    border: "4px solid rgba(255, 255, 255, 0.8)",
    boxShadow: "0 8px 32px rgba(0,0,0,0.3)",
    animation: "bounce 2s infinite"
  },
  cookingBubbles: {
    position: "absolute",
    bottom: "-20px",
    left: "50%",
    transform: "translateX(-50%)",
    display: "flex",
    gap: "8px"
  },
  bubble: {
    width: "8px",
    height: "8px",
    backgroundColor: "rgba(255,255,255,0.8)",
    borderRadius: "50%",
    animation: "bubble 1.5s ease-in-out infinite"
  },
  title: {
    fontSize: "3.5rem",
    fontWeight: "bold",
    marginBottom: "1rem",
    textShadow: "2px 2px 8px rgba(0,0,0,0.3)",
    background: "linear-gradient(45deg, #FFD700, #FFA500, #FF6B6B)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text",
    animation: "gradientShift 3s ease-in-out infinite"
  },
  titleAccent: {
    background: "linear-gradient(45deg, #FF6B6B, #FF8E53)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text"
  },
  subtitle: {
    fontSize: "1.3rem",
    opacity: 0.9,
    marginBottom: "3rem",
    fontStyle: "italic",
    fontWeight: "300",
    animation: "fadeInOut 2s ease-in-out infinite"
  },
  progressContainer: {
    width: "300px",
    height: "8px",
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: "10px",
    marginBottom: "1rem",
    overflow: "hidden",
    position: "relative",
    boxShadow: "0 2px 8px rgba(0,0,0,0.2)"
  },
  progressBar: {
    height: "100%",
    background: "linear-gradient(90deg, #FFD700, #FF8E53)",
    borderRadius: "10px",
    transition: "width 0.3s ease",
    boxShadow: "0 0 20px rgba(255,215,0,0.5)"
  },
  progressText: {
    position: "absolute",
    top: "12px",
    left: "50%",
    transform: "translateX(-50%)",
    fontSize: "0.8rem",
    fontWeight: "600",
    color: "#FFD700"
  },
  loadingDots: {
    display: "flex",
    justifyContent: "center",
    gap: "8px",
    marginBottom: "2rem"
  },
  dot: {
    width: "12px",
    height: "12px",
    backgroundColor: "rgba(255,255,255,0.6)",
    borderRadius: "50%",
    animation: "pulse 1.4s ease-in-out infinite both"
  },
  footer: {
    position: "absolute",
    bottom: "2rem",
    textAlign: "center"
  },
  footerText: {
    fontSize: "0.9rem",
    opacity: 0.7,
    fontStyle: "italic"
  }
};

// Add CSS animations
if (typeof document !== 'undefined') {
  const styleElement = document.createElement('style');
  styleElement.textContent = `
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0) scale(1); }
      40% { transform: translateY(-10px) scale(1.05); }
      60% { transform: translateY(-5px) scale(1.02); }
    }
    
    @keyframes bubble {
      0%, 100% { transform: translateY(0); opacity: 0.5; }
      50% { transform: translateY(-15px); opacity: 1; }
    }
    
    @keyframes gradientShift {
      0%, 100% { filter: hue-rotate(0deg); }
      50% { filter: hue-rotate(45deg); }
    }
    
    @keyframes fadeInOut {
      0%, 100% { opacity: 0.7; }
      50% { opacity: 1; }
    }
    
    @keyframes pulse {
      0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
      40% { transform: scale(1.2); opacity: 1; }
    }
  `;
  document.head.appendChild(styleElement);
}

export default SplashScreen;