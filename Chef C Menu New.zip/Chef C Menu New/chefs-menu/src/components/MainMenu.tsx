import React, { useState } from "react";

interface MainMenuProps {
  onSelectCategory: (category: string) => void;
  onViewAllDishes: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onSelectCategory, onViewAllDishes }) => {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  const categories = [
    { 
      name: "Starters", 
      image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      color: "#4CAF50",
      gradient: "linear-gradient(135deg, #4CAF50, #45a049)",
      description: "Light beginnings to awaken the palate"
    },
    { 
      name: "Mains", 
      image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80",
      color: "#FF9800",
      gradient: "linear-gradient(135deg, #FF9800, #f57c00)",
      description: "Hearty dishes that satisfy the soul"
    },
    { 
      name: "Desserts", 
      image: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80",
      color: "#E91E63",
      gradient: "linear-gradient(135deg, #E91E63, #c2185b)",
      description: "Sweet endings to complete the experience"
    }
  ];

  return (
    <div style={styles.container}>
      {/* Header Section */}
      <div style={styles.header}>
        <div style={styles.chefWelcome}>
          <div style={styles.chefImage}></div>
          <h1 style={styles.title}>Welcome to Your Kitchen</h1>
        </div>
        <p style={styles.subtitle}>
          Craft your culinary masterpiece. Choose a category to begin your creation journey.
        </p>
      </div>

      {/* Categories Grid */}
      <div style={styles.categoriesGrid}>
        {categories.map((category) => (
          <div
            key={category.name}
            style={{
              ...styles.categoryCard,
              transform: hoveredCategory === category.name ? 'translateY(-10px) scale(1.05)' : 'translateY(0) scale(1)',
              boxShadow: hoveredCategory === category.name 
                ? `0 20px 40px ${category.color}40` 
                : '0 8px 32px rgba(0,0,0,0.1)',
            }}
            onMouseEnter={() => setHoveredCategory(category.name)}
            onMouseLeave={() => setHoveredCategory(null)}
            onClick={() => onSelectCategory(category.name)}
          >
            <div 
              style={{
                ...styles.cardImage,
                backgroundImage: `url(${category.image})`
              }}
            >
              <div style={styles.imageOverlay}></div>
            </div>
            
            <div style={styles.cardContent}>
              <h3 style={styles.categoryName}>{category.name}</h3>
              <p style={styles.categoryDescription}>{category.description}</p>
              
              <div style={styles.cardHover}>
                <span style={styles.hoverText}>Start Creating</span>
                <span style={styles.hoverArrow}>→</span>
              </div>
            </div>

            {/* Category Accent */}
            <div 
              style={{
                ...styles.categoryAccent,
                background: category.gradient
              }}
            ></div>
          </div>
        ))}
      </div>

      {/* Action Section */}
      <div style={styles.actionSection}>
        <div style={styles.divider}>
          <span style={styles.dividerText}>or</span>
        </div>
        
        <button 
          onClick={onViewAllDishes} 
          style={styles.filterButton}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = '0 8px 25px rgba(33, 150, 243, 0.4)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 4px 15px rgba(33, 150, 243, 0.3)';
          }}
        >
          <span style={styles.filterIcon}>🔍</span>
          <span style={styles.filterText}>
            Explore All Dishes
            <span style={styles.filterSubtext}>Filter & Browse Complete Menu</span>
          </span>
          <span style={styles.filterArrow}>→</span>
        </button>
      </div>

      {/* Footer */}
      <div style={styles.footer}>
        <p style={styles.footerText}>
          Crafted with <span style={styles.heart}>❤️</span> for passionate chefs
        </p>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    padding: "2rem",
    fontFamily: "'Poppins', sans-serif",
    position: "relative",
    overflow: "hidden"
  },
  header: {
    textAlign: "center",
    marginBottom: "4rem",
    color: "white"
  },
  chefWelcome: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "1rem",
    marginBottom: "1rem"
  },
  chefImage: {
    width: "80px",
    height: "80px",
    backgroundImage: "url('https://images.unsplash.com/photo-1583394293214-28ded15ee548?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    borderRadius: "50%",
    border: "3px solid rgba(255,255,255,0.8)",
    boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
    animation: "bounce 3s infinite"
  },
  title: {
    fontSize: "3rem",
    fontWeight: "bold",
    margin: 0,
    textShadow: "2px 2px 8px rgba(0,0,0,0.3)",
    background: "linear-gradient(45deg, #FFD700, #FFA500)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text"
  },
  subtitle: {
    fontSize: "1.2rem",
    opacity: 0.9,
    fontWeight: "300",
    maxWidth: "500px",
    margin: "0 auto",
    lineHeight: "1.6"
  },
  categoriesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: "2rem",
    maxWidth: "1100px",
    margin: "0 auto 4rem",
    padding: "0 1rem"
  },
  categoryCard: {
    background: "rgba(255, 255, 255, 0.95)",
    borderRadius: "20px",
    cursor: "pointer",
    transition: "all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
    position: "relative",
    overflow: "hidden",
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    minHeight: "400px",
    display: "flex",
    flexDirection: "column"
  },
  cardImage: {
    height: "200px",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    position: "relative"
  },
  imageOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: "linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.3) 100%)"
  },
  cardContent: {
    padding: "2rem",
    flex: 1,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    position: "relative",
    zIndex: 2
  },
  categoryName: {
    fontSize: "1.8rem",
    fontWeight: "bold",
    margin: "0 0 1rem 0",
    color: "#333",
    transition: "all 0.3s ease"
  },
  categoryDescription: {
    color: "#666",
    fontSize: "0.95rem",
    lineHeight: "1.5",
    margin: "0 0 1.5rem 0",
    transition: "all 0.3s ease"
  },
  cardHover: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    color: "#2196F3",
    fontWeight: "600",
    fontSize: "0.9rem",
    opacity: 0,
    transform: "translateY(10px)",
    transition: "all 0.3s ease"
  },
  hoverText: {
    fontSize: "0.9rem"
  },
  hoverArrow: {
    fontSize: "1.1rem",
    transition: "transform 0.3s ease"
  },
  categoryAccent: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: "4px",
    transition: "all 0.3s ease"
  },
  actionSection: {
    textAlign: "center",
    marginBottom: "3rem"
  },
  divider: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "2rem 0",
    color: "rgba(255,255,255,0.7)"
  },
  dividerText: {
    padding: "0 1rem",
    fontSize: "0.9rem",
    fontWeight: "300"
  },
  filterButton: {
    background: "linear-gradient(135deg, #2196F3, #1976D2)",
    color: "white",
    border: "none",
    padding: "1.2rem 2rem",
    fontSize: "1.1rem",
    borderRadius: "15px",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: "1rem",
    margin: "0 auto",
    boxShadow: "0 4px 15px rgba(33, 150, 243, 0.3)",
    transition: "all 0.3s ease",
    fontWeight: "600",
    minWidth: "300px",
    justifyContent: "space-between"
  },
  filterIcon: {
    fontSize: "1.3rem"
  },
  filterText: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "0.2rem"
  },
  filterSubtext: {
    fontSize: "0.8rem",
    opacity: 0.9,
    fontWeight: "400"
  },
  filterArrow: {
    fontSize: "1.2rem",
    transition: "transform 0.3s ease"
  },
  footer: {
    textAlign: "center",
    color: "rgba(255,255,255,0.7)"
  },
  footerText: {
    fontSize: "0.9rem",
    fontWeight: "300"
  },
  heart: {
    animation: "heartbeat 1.5s ease-in-out infinite",
    display: "inline-block"
  }
};

// Add CSS animations
if (typeof document !== 'undefined') {
  const styleElement = document.createElement('style');
  styleElement.textContent = `
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-8px); }
      60% { transform: translateY(-4px); }
    }
    
    @keyframes heartbeat {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.1); }
    }

    .category-card:hover .card-hover {
      opacity: 1;
      transform: translateY(0);
    }

    .category-card:hover .category-name {
      color: #2196F3;
    }

    .category-card:hover .category-description {
      color: #888;
    }

    .category-card:hover .hover-arrow {
      transform: translateX(3px);
    }

    .filter-button:hover .filter-arrow {
      transform: translateX(3px);
    }
  `;
  document.head.appendChild(styleElement);
}

export default MainMenu;