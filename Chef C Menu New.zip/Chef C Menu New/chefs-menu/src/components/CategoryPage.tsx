import React, { useState } from "react";

export interface MenuItem {
  name: string;
  price: number;
  description: string;
  category: string;
  image?: string;
}

interface CategoryPageProps {
  category: string;
  onBack: () => void;
  onAddItem: (item: MenuItem) => void;
  items: MenuItem[];
}

const CategoryPage: React.FC<CategoryPageProps> = ({ category, onBack, onAddItem, items }) => {
  const [form, setForm] = useState<Omit<MenuItem, 'category'>>({ 
    name: "", 
    price: 0, 
    description: "",
    image: ""
  });
  const [isFormExpanded, setIsFormExpanded] = useState(false);

  // Simple category configurations
  const getCategoryConfig = () => {
    const configs = {
      "Starters": { 
        color: "#4CAF50", 
        gradient: "linear-gradient(135deg, #4CAF50, #45a049)",
        headerImage: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
      },
      "Mains": { 
        color: "#FF9800", 
        gradient: "linear-gradient(135deg, #FF9800, #f57c00)",
        headerImage: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80"
      },
      "Desserts": { 
        color: "#E91E63", 
        gradient: "linear-gradient(135deg, #E91E63, #c2185b)",
        headerImage: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80"
      }
    };
    
    return configs[category as keyof typeof configs] || {
      color: "#667eea",
      gradient: "linear-gradient(135deg, #667eea, #764ba2)",
      headerImage: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
    };
  };

  const categoryConfig = getCategoryConfig();

  const addItem = () => {
    if (!form.name.trim()) return;
    const newItem: MenuItem = {
      ...form,
      category: category,
      image: form.image || getDefaultImage(category)
    };
    onAddItem(newItem);
    setForm({ name: "", price: 0, description: "", image: "" });
    setIsFormExpanded(false);
  };

  const getDefaultImage = (cat: string) => {
    const defaultImages = {
      "Starters": "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
      "Mains": "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80",
      "Desserts": "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80"
    };
    return defaultImages[cat as keyof typeof defaultImages] || "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80";
  };

  const categoryItems = items.filter(item => item.category === category);
  const totalValue = categoryItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={styles.container}>
      {/* Header with Background Image */}
      <div 
        style={{
          ...styles.header,
          backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(${categoryConfig.headerImage})`
        }}
      >
        <button onClick={onBack} style={styles.backBtn}>
          ← Back to Menu
        </button>
        
        <div style={styles.titleSection}>
          <h1 style={styles.title}>{category}</h1>
          <p style={styles.subtitle}>Craft your perfect {category.toLowerCase()} menu</p>
        </div>

        <div style={styles.stats}>
          <div style={styles.statCard}>
            <div style={styles.statNumber}>{categoryItems.length}</div>
            <div style={styles.statLabel}>Total Dishes</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statNumber}>R{totalValue.toFixed(2)}</div>
            <div style={styles.statLabel}>Total Value</div>
          </div>
        </div>
      </div>

      <div style={styles.content}>
        {/* Add Dish Form */}
        <div style={styles.formSection}>
          <div style={styles.formContainer}>
            <div 
              style={styles.formHeader}
              onClick={() => setIsFormExpanded(!isFormExpanded)}
            >
              <div style={styles.formHeaderContent}>
                <div style={styles.formIcon}>+</div>
                <div>
                  <h3 style={styles.formTitle}>Add New Dish</h3>
                  <p style={styles.formSubtitle}>Create a new {category.toLowerCase()} masterpiece</p>
                </div>
              </div>
              <span style={styles.expandIcon}>{isFormExpanded ? "▲" : "▼"}</span>
            </div>

            {isFormExpanded && (
              <div style={styles.formContent}>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Dish Name</label>
                  <input
                    type="text"
                    placeholder="Enter dish name..."
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    style={styles.input}
                  />
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Price (R)</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    value={form.price || ""}
                    onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) || 0 })}
                    style={styles.input}
                  />
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Description</label>
                  <textarea
                    placeholder="Describe your dish..."
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    style={styles.textarea}
                    rows={3}
                  />
                </div>

                <button 
                  onClick={addItem} 
                  style={{
                    ...styles.addButton,
                    background: categoryConfig.gradient
                  }}
                  disabled={!form.name.trim()}
                >
                  Add to {category} Menu
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Menu Items */}
        <div style={styles.itemsSection}>
          <h2 style={styles.sectionTitle}>
            Your {category} Collection ({categoryItems.length})
          </h2>

          {categoryItems.length === 0 ? (
            <div style={styles.emptyState}>
              <div style={styles.emptyImage}></div>
              <h3 style={styles.emptyTitle}>No {category.toLowerCase()} dishes yet</h3>
              <p style={styles.emptyText}>
                Start by adding your first delicious creation!
              </p>
              <button 
                onClick={() => setIsFormExpanded(true)}
                style={styles.emptyAction}
              >
                Create Your First Dish
              </button>
            </div>
          ) : (
            <div style={styles.itemsGrid}>
              {categoryItems.map((item, index) => (
                <div key={index} style={styles.dishCard}>
                  <div 
                    style={{
                      ...styles.dishImage,
                      backgroundImage: `url(${item.image || getDefaultImage(category)})`
                    }}
                  ></div>
                  
                  <div style={styles.dishContent}>
                    <div style={styles.dishHeader}>
                      <h3 style={styles.dishName}>{item.name}</h3>
                      <div style={styles.priceTag}>
                        R{item.price.toFixed(2)}
                      </div>
                    </div>
                    
                    <p style={styles.dishDescription}>{item.description}</p>
                    
                    <div style={styles.dishFooter}>
                      <span style={styles.categoryBadge}>
                        {category}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Simple styles without complex properties
const styles: { [key: string]: React.CSSProperties } = {
  container: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)",
    fontFamily: "'Poppins', sans-serif"
  },
  header: {
    backgroundSize: "cover",
    backgroundPosition: "center",
    color: "white",
    padding: "2rem",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    minHeight: "200px"
  },
  backBtn: {
    background: "rgba(244, 67, 54, 0.9)",
    border: "none",
    color: "white",
    padding: "0.75rem 1.5rem",
    borderRadius: "25px",
    cursor: "pointer",
    fontWeight: "600"
  },
  titleSection: {
    textAlign: "center",
    flex: 1
  },
  title: {
    fontSize: "2.5rem",
    fontWeight: "bold",
    margin: "0 0 0.5rem 0",
    textShadow: "2px 2px 4px rgba(0,0,0,0.3)"
  },
  subtitle: {
    fontSize: "1.1rem",
    opacity: 0.9,
    margin: 0
  },
  stats: {
    display: "flex",
    gap: "1rem"
  },
  statCard: {
    background: "rgba(255,255,255,0.2)",
    padding: "1rem",
    borderRadius: "15px",
    textAlign: "center",
    minWidth: "100px"
  },
  statNumber: {
    fontSize: "1.5rem",
    fontWeight: "bold",
    marginBottom: "0.25rem"
  },
  statLabel: {
    fontSize: "0.8rem",
    opacity: 0.9
  },
  content: {
    padding: "2rem",
    maxWidth: "1200px",
    margin: "0 auto"
  },
  formSection: {
    marginBottom: "3rem"
  },
  formContainer: {
    background: "white",
    borderRadius: "20px",
    boxShadow: "0 8px 32px rgba(0,0,0,0.1)",
    overflow: "hidden"
  },
  formHeader: {
    padding: "1.5rem 2rem",
    background: "linear-gradient(135deg, #74b9ff, #0984e3)",
    color: "white",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    cursor: "pointer"
  },
  formHeaderContent: {
    display: "flex",
    alignItems: "center",
    gap: "1rem"
  },
  formIcon: {
    width: "50px",
    height: "50px",
    background: "rgba(255,255,255,0.2)",
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "1.5rem",
    fontWeight: "bold"
  },
  formTitle: {
    margin: "0 0 0.25rem 0",
    fontSize: "1.3rem"
  },
  formSubtitle: {
    margin: 0,
    opacity: 0.9,
    fontSize: "0.9rem"
  },
  expandIcon: {
    fontSize: "1rem"
  },
  formContent: {
    padding: "2rem",
    display: "flex",
    flexDirection: "column",
    gap: "1.5rem"
  },
  inputGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem"
  },
  label: {
    fontWeight: "600",
    color: "#333",
    fontSize: "0.9rem"
  },
  input: {
    padding: "0.75rem 1rem",
    border: "2px solid #e0e0e0",
    borderRadius: "10px",
    fontSize: "1rem",
    outline: "none"
  },
  textarea: {
    padding: "0.75rem 1rem",
    border: "2px solid #e0e0e0",
    borderRadius: "10px",
    fontSize: "1rem",
    resize: "vertical",
    minHeight: "80px",
    outline: "none"
  },
  addButton: {
    color: "white",
    border: "none",
    padding: "1rem 2rem",
    borderRadius: "10px",
    fontSize: "1rem",
    fontWeight: "600",
    cursor: "pointer",
    marginTop: "1rem"
  },
  itemsSection: {
    background: "white",
    borderRadius: "20px",
    padding: "2rem",
    boxShadow: "0 8px 32px rgba(0,0,0,0.1)"
  },
  sectionTitle: {
    margin: "0 0 2rem 0",
    color: "#333",
    fontSize: "1.8rem"
  },
  emptyState: {
    textAlign: "center",
    padding: "4rem 2rem",
    color: "#666"
  },
  emptyImage: {
    width: "200px",
    height: "150px",
    backgroundSize: "cover",
    backgroundPosition: "center",
    borderRadius: "15px",
    margin: "0 auto 2rem",
    opacity: 0.7
  },
  emptyTitle: {
    fontSize: "1.5rem",
    margin: "0 0 1rem 0",
    color: "#333"
  },
  emptyText: {
    fontSize: "1rem",
    margin: "0 0 2rem 0",
    opacity: 0.8
  },
  emptyAction: {
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    border: "none",
    padding: "1rem 2rem",
    borderRadius: "25px",
    fontSize: "1rem",
    fontWeight: "600",
    cursor: "pointer"
  },
  itemsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(350px, 1fr))",
    gap: "1.5rem"
  },
  dishCard: {
    background: "white",
    borderRadius: "15px",
    overflow: "hidden",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    border: "1px solid rgba(0,0,0,0.05)"
  },
  dishImage: {
    height: "200px",
    backgroundSize: "cover",
    backgroundPosition: "center"
  },
  dishContent: {
    padding: "1.5rem"
  },
  dishHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "1rem"
  },
  dishName: {
    margin: "0",
    color: "#333",
    fontSize: "1.3rem",
    fontWeight: "600",
    flex: 1
  },
  priceTag: {
    background: "linear-gradient(135deg, #667eea, #764ba2)",
    color: "white",
    padding: "0.5rem 1rem",
    borderRadius: "20px",
    fontSize: "1rem",
    fontWeight: "bold"
  },
  dishDescription: {
    margin: "0 0 1.5rem 0",
    color: "#666",
    lineHeight: "1.6"
  },
  dishFooter: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  categoryBadge: {
    background: "rgba(116, 185, 255, 0.1)",
    color: "#74b9ff",
    padding: "0.4rem 0.8rem",
    borderRadius: "15px",
    fontSize: "0.8rem",
    fontWeight: "600"
  }
};

export default CategoryPage;