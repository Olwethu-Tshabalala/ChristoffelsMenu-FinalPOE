import React, { useState, useEffect } from "react";
import SplashScreen from "./components/SplashScreen";
import MainMenu from "./components/MainMenu";
import CategoryPage, { MenuItem } from "./components/CategoryPage";
import FilterPage from "./components/FilterPage";

type AppState = "splash" | "main" | "category" | "filter";

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>("splash");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [transitioning, setTransitioning] = useState(false);
  const [previousState, setPreviousState] = useState<AppState>("splash");

  // Updated sample dishes with CORRECT specific food images
  useEffect(() => {
    const sampleDishes: MenuItem[] = [
      {
        name: "Bruschetta",
        price: 45,
        description: "Toasted bread topped with fresh tomatoes, basil, and garlic",
        category: "Starters",
        image: "https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80"
      },
      {
        name: "Caesar Salad",
        price: 65,
        description: "Crisp romaine lettuce with parmesan and croutons",
        category: "Starters",
        image: "https://images.unsplash.com/photo-1546793665-c74683f339c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
      },
      {
        name: "Grilled Salmon",
        price: 185,
        description: "Fresh salmon fillet with lemon butter sauce and seasonal vegetables",
        category: "Mains",
        image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
      },
      {
        name: "Beef Burger",
        price: 95,
        description: "Premium beef patty with cheese, lettuce, and special sauce",
        category: "Mains",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1998&q=80"
      },
      {
        name: "Chocolate Lava Cake",
        price: 55,
        description: "Warm chocolate cake with molten center and vanilla ice cream",
        category: "Desserts",
        image: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2080&q=80"
      },
      {
        name: "Tiramisu",
        price: 65,
        description: "Classic Italian dessert with coffee-soaked ladyfingers",
        category: "Desserts",
        image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
      }
    ];
    setMenuItems(sampleDishes);
  }, []);

  const handleTransition = (newState: AppState, callback?: () => void) => {
    setTransitioning(true);
    setPreviousState(appState);
    
    setTimeout(() => {
      setAppState(newState);
      setTransitioning(false);
      if (callback) callback();
    }, 300);
  };

  const handleAddItem = (newItem: MenuItem) => {
    setMenuItems(prev => {
      const updatedItems = [...prev, newItem];
      localStorage.setItem('chefMenuItems', JSON.stringify(updatedItems));
      return updatedItems;
    });
  };

  const handleSelectCategory = (category: string) => {
    setSelectedCategory(category);
    handleTransition("category");
  };

  const handleBackToMain = () => {
    handleTransition("main", () => {
      setSelectedCategory("");
    });
  };

  const handleViewAllDishes = () => {
    handleTransition("filter");
  };

  const handleFinishSplash = () => {
    handleTransition("main");
  };

  // Load saved items from localStorage
  useEffect(() => {
    const savedItems = localStorage.getItem('chefMenuItems');
    if (savedItems) {
      try {
        const parsedItems = JSON.parse(savedItems);
        setMenuItems(parsedItems);
      } catch (error) {
        console.log('Error loading saved items:', error);
      }
    }
  }, []);

  const getTransitionClass = () => {
    if (!transitioning) return "";
    
    const directions: Record<string, Record<string, string>> = {
      "splash": { "main": "slide-out-left" },
      "main": { 
        "splash": "slide-in-right",
        "category": "slide-out-left",
        "filter": "slide-out-left"
      },
      "category": { 
        "main": "slide-in-right",
        "filter": "slide-out-left"
      },
      "filter": { 
        "main": "slide-in-right",
        "category": "slide-in-right"
      }
    };

    return directions[previousState]?.[appState] || "";
  };

  const renderCurrentScreen = () => {
    const transitionClass = getTransitionClass();

    switch (appState) {
      case "splash":
        return (
          <div className={`screen ${transitionClass}`}>
            <SplashScreen onFinish={handleFinishSplash} />
          </div>
        );
      
      case "category":
        return (
          <div className={`screen ${transitionClass}`}>
            <CategoryPage
              category={selectedCategory}
              onBack={handleBackToMain}
              onAddItem={handleAddItem}
              items={menuItems}
            />
          </div>
        );
      
      case "filter":
        return (
          <div className={`screen ${transitionClass}`}>
            <FilterPage
              items={menuItems}
              onBack={handleBackToMain}
            />
          </div>
        );
      
      case "main":
      default:
        return (
          <div className={`screen ${transitionClass}`}>
            <MainMenu
              onSelectCategory={handleSelectCategory}
              onViewAllDishes={handleViewAllDishes}
            />
          </div>
        );
    }
  };

  return (
    <div style={styles.app}>
      <div style={styles.background}></div>
      
      {appState !== "splash" && (
        <div style={styles.navigationDots}>
          <div 
            style={{
              ...styles.navDot,
              ...(appState === "main" ? styles.navDotActive : {})
            }}
            title="Main Menu"
          ></div>
          <div 
            style={{
              ...styles.navDot,
              ...(appState === "category" ? styles.navDotActive : {})
            }}
            title={`${selectedCategory || "Category"}`}
          ></div>
          <div 
            style={{
              ...styles.navDot,
              ...(appState === "filter" ? styles.navDotActive : {})
            }}
            title="Dish Explorer"
          ></div>
        </div>
      )}

      <div style={styles.content}>
        {renderCurrentScreen()}
      </div>

      {appState !== "splash" && (
        <footer style={styles.footer}>
          <p style={styles.footerText}>
            Chef's Menu App • Crafted with <span style={styles.heart}>❤️</span> for culinary excellence
          </p>
        </footer>
      )}

      <style>
        {`
          .screen {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            transition: all 0.3s ease;
          }

          .slide-out-left {
            animation: slideOutLeft 0.3s forwards;
          }

          .slide-in-right {
            animation: slideInRight 0.3s forwards;
          }

          @keyframes slideOutLeft {
            from {
              transform: translateX(0);
              opacity: 1;
            }
            to {
              transform: translateX(-100%);
              opacity: 0;
            }
          }

          @keyframes slideInRight {
            from {
              transform: translateX(100%);
              opacity: 0;
            }
            to {
              transform: translateX(0);
              opacity: 1;
            }
          }
        `}
      </style>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  app: {
    minHeight: "100vh",
    position: "relative",
    overflow: "hidden",
    fontFamily: "'Poppins', sans-serif, Arial, sans-serif"
  },
  background: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    zIndex: -1
  },
  content: {
    position: "relative",
    minHeight: "100vh",
    width: "100%",
    overflow: "hidden"
  },
  navigationDots: {
    position: "fixed",
    top: "50%",
    right: "20px",
    transform: "translateY(-50%)",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    zIndex: 1000
  },
  navDot: {
    width: "12px",
    height: "12px",
    borderRadius: "50%",
    background: "rgba(255, 255, 255, 0.3)",
    cursor: "pointer",
    transition: "all 0.3s ease",
    border: "2px solid rgba(255, 255, 255, 0.5)"
  },
  navDotActive: {
    background: "#FFD700",
    transform: "scale(1.2)",
    borderColor: "#FFA500"
  },
  footer: {
    position: "fixed",
    bottom: 0,
    left: 0,
    right: 0,
    background: "rgba(0, 0, 0, 0.8)",
    color: "white",
    padding: "1rem",
    textAlign: "center",
    zIndex: 100
  },
  footerText: {
    margin: 0,
    fontSize: "0.9rem",
    opacity: 0.8,
    fontWeight: "300"
  },
  heart: {
    color: "#ff4757"
  }
};

export default App;